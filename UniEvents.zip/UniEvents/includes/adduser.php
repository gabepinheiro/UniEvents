<?PHP

include('conexao.php');

$nome = $_POST['nome'];
$tel = $_POST['sobrenome'];
$email = $_POST['email'];
$datanasc = $_POST['dataNasc'];
$senha = $_POST['senha'];
$sql = "insert into usuario values('$nome','$sobrenome','$email','$datanasc','$senha')";
mysql_query($sql);

?>