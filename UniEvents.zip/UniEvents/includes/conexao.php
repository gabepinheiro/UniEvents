<?php 

$host = 'localhost';
$user = 'root';
$pass = 'root';
$db = 'unievents';

$conexao = mysql_connect($host, $user, $pass);

mysql_select_db($db, $conexao);

?>