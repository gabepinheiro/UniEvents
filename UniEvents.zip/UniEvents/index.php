<?php
include('includes/conexao.php');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Crie e Gerencie eventos com o UniEvents</title>
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
	<link rel="icon" href="img/favicon.ico" type="image/x-icon">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script>   
	$(document).ready(function(){	
		$('#change').click(function(){
			$("#signin").toggleClass("hidden");
			$("#signup").toggleClass("hidden");
			if(document.getElementById('change').innerHTML == "Registrar-se") {
				document.getElementById('change').innerHTML = "Acessar Conta"
			}
			else {
				document.getElementById('change').innerHTML = "Registrar-se"
			}
		});
		$('.create-acc').click(function(){
			$("#signin").toggleClass("hidden");
			$("#signup").toggleClass("hidden");
			if(document.getElementById('change').innerHTML == "Registrar-se") {
				document.getElementById('change').innerHTML = "Acessar Conta"
			}
			else {
				document.getElementById('change').innerHTML = "Registrar-se"
			}
		});
		$('.access-acc').click(function(){
			$("#signin").toggleClass("hidden");
			$("#signup").toggleClass("hidden");
			if(document.getElementById('change').innerHTML == "Registrar-se") {
				document.getElementById('change').innerHTML = "Acessar Conta"
			}
			else {
				document.getElementById('change').innerHTML = "Registrar-se"
			}
		});
	});
	</script>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="index.css" rel="stylesheet">
</head>

<body>

	<nav class="navbar navbar-expand-lg" role="navigation">
		<div class="container">
			<img src="img/logotipo.png" class="logotype" alt="Logotipo" />
			<ul class="nav navbar-nav navbar-right ml-auto">
				<li class="nav-item"><a id="change" class="nav-link">Registrar-se</a></li>
			</ul>
		</div>
	</nav>
	
	<div class="container-fluid bg-light">
	
    <div class="container featurette">
	<div class="row">
        <div class="col-md-7">
            <h2 class="featurette-heading">Crie e gerencie seus eventos com a UniEvents!</h2><br>
            <p class="lead">Com a plataforma da UniEvents, qualquer festa, encontros entre amigos, encontros de trabalho e diversos outros eventos podem ser feitos e gerenciados de forma simples e rápida, seja com o uso de ingressos virtuais ou somente com lembretes via e-mail.</p>
			<p class="lead">Faça hoje mesmo uma conta conosco e facilite sua vida!</p>
        </div>
		<div class="col-md-5">
			<div id="signup">
				<div class="signup">
				<form class="form-sign" method="post">
					<h4 class="form-signin-heading">Criar uma conta</h4>
					<label for="inputName" class="sr-only">Nome</label>
					<input type="text" id="inputName" class="form-control" placeholder="Nome" required="">
					<label for="inputName" class="sr-only">Sobrenome</label>
					<input type="text" id="inputName" class="form-control" placeholder="Sobrenome" required="">
					<label for="inputEmail" class="sr-only">Data de Nascimento</label>
					<input type="date" id="inputBorn" class="form-control" required="">
					<label for="inputEmail" class="sr-only">Email address</label>
					<input type="email" id="inputEmail" class="form-control" placeholder="E-mail" required="">
					<label for="inputPassword" class="sr-only">Password</label>
					<input type="password" id="inputPassword" class="form-control" placeholder="Password" required="">
					<button class="btn btn-lg btn-primary btn-block" type="submit">Criar Conta</button>
					<div class="other-opt">
						<p class="lead text-left privacy-policy-txt">Criando sua conta, você concorda com as nossas <a href="#">Políticas de Privacidade e Termos</a></p>
						<p class="lead text-left access-acc"><a href="#">Quer acessar sua conta?</a></p>
					</div>
				</form>
				</div>
			</div>	
			<div id="signin" class="hidden">
				<div class="signin">
				<form class="form-sign">
					<h4 class="form-signin-heading">Acessar conta</h4>
					<label for="inputEmail" class="sr-only">Email address</label>
					<input type="email" id="inputEmail" class="form-control" placeholder="E-mail" required="">
					<label for="inputPassword" class="sr-only">Password</label>
					<input type="password" id="inputPassword" class="form-control" placeholder="Password" required="">
					<button class="btn btn-lg btn-primary btn-block" type="submit">Entrar</button>
					<div class="other-opt">
						<p class="lead text-left fgt-password"><a href="#">Esqueceu a senha?</a></p>
						<p class="lead text-left create-acc"><a href="#">Quer criar uma conta?</a></p>
					</div>
				</form>
				</div>
			</div> 
		</div>	
	</div>
	</div>
	
	</div>
	
	<hr class="featurette-divider">	
	
	<div class="container featurette bonus-features">
		<div class="row">
			<div class="col-md-2 thumb-bonus text-center"><span class="align"></span><img src="img/calendar.png"></div>
			<div class="col-md-10 text-left"><p class="lead"><h3>Gerenciador de Datas</h3><br>Marque eventos, gerencie e receba notificações em seu smartphone ou diretamente em seu e-mail.</p></div>
		</div>
		<hr class="featurette-divider">	
		<div class="row">
			<div class="col-md-2 thumb-bonus text-center"><span class="align"></span><img src="img/analytics.png"></div>
			<div class="col-md-10 text-left"><p class="lead"><h3>Estatísticas Detalhadas</h3><br>Visualize quais eventos criados possuem maior relevância, quais são mais rentáveis, tenha total controle sobre os dados de cada evento criado!</p></div>
		</div>
		<hr class="featurette-divider">	
		<div class="row">
			<div class="col-md-2 thumb-bonus text-center"><span class="align"></span><img src="img/barcode.png"></div>
			<div class="col-md-10 text-left"><p class="lead"><h3>Ingressos Virtuais</h3><br>Faça um evento com ingressos virtuais para controle de público, podendo utilizar via smartphones ou se quiser, imprimir em papel.</p></div>
		</div>
	</div>
	
	<hr class="featurette-divider">	
	
    <footer class="bg-dark">
		<div class="container">
			<div class="row">
				<div class="col-md-4"><span class="align"></span><img src="img/logotipo_white.png" class="logotype-footer" alt="Logotipo" /></div>
				<div class="col-md-4">
					<ul class="nav navbar-nav">
						<li><a href="#" class="lead">Sobre Nós</a></li>
						<li><a href="#" class="lead">Contate-nos</a></li>
						<li><a href="#" class="lead">Política de Privacidade</a></li>
						<li><a href="#" class="lead">Segurança</a></li>
						<li><a href="#" class="lead">Ajuda</a></li>
					</ul>
				</div>
				</div>
			</div>
			<div class="last text-center">
				<div class="col-md-12">© 2017 UniEvents - Todos direitos reservados.</div>
			</div>
		</div>
	</footer>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
	
</body>
</html>